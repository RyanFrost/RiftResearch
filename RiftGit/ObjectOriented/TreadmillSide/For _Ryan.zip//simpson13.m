function integral = simpson13(step,point1,point2,point3)
integral = step/3*(point1+4*point2+point3);

